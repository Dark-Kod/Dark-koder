#include <stdio.h>
int main(){
	//declaring variable
	char str[30];

	//reading user input
	scanf("%s",str);

	//printing str
	printf("%s\n",str);
	
	return 0;
}