#include <stdio.h>
int main(){
	//declaring variables
	int i,n;

	//reading value of n
	scanf("%d",&n);

	//for loop
	for(i=1;i<=n;i++){
		printf("%d\n",i);
	}
	return 0;
}