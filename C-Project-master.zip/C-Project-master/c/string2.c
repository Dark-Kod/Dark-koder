#include <stdio.h>
int main(){
	//declaring variable
	char str[30];

	//reading using gets()
	gets(str);

	//printing using puts()
	puts(str);
	return 0;
}