#define max(x,y) (x>y?x:y)	//find maximim value
#define min(x,y) (x<y?x:y)	//find minimum value